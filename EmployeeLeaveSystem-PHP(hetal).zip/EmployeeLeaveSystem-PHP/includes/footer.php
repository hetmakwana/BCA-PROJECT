<footer>
        <div class="footer-area">
                <p>© <?php echo date("Y");?> Employee Leave Management System </a></p>
        </div>
</footer>