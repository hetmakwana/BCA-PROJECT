-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2023 at 08:05 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employeeleavedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(55) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `fullname`, `email`, `updationDate`) VALUES
(4, 'Meet', '202cb962ac59075b964b07152d234b70', 'Halani Meet', 'meet@gmail.com', '2023-02-25 16:57:36');

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `id` int(11) NOT NULL,
  `DepartmentName` varchar(150) DEFAULT NULL,
  `DepartmentShortName` varchar(100) NOT NULL,
  `DepartmentCode` varchar(50) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`id`, `DepartmentName`, `DepartmentShortName`, `DepartmentCode`, `CreationDate`) VALUES
(9, 'Human Resources ', 'HR', 'HR160', '2023-02-25 17:04:22'),
(10, 'Information Technology', 'IT', 'IT807', '2023-02-25 17:11:20'),
(11, 'Operations', 'OP', 'OP640', '2023-02-25 17:12:31'),
(12, 'Volunteer', 'VL', 'VL9696', '2023-02-25 17:13:08'),
(13, 'Marketing', 'MK', 'MK369', '2023-02-25 17:13:41'),
(14, 'Finance', 'FI', 'FI123', '2023-02-25 17:14:09'),
(15, 'Sales', 'SS', 'SS469', '2023-02-25 17:14:34'),
(16, 'Research', 'RS', 'RS666', '2023-02-25 17:15:03');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `id` int(11) NOT NULL,
  `EmpId` varchar(100) NOT NULL,
  `FirstName` varchar(150) NOT NULL,
  `LastName` varchar(150) NOT NULL,
  `EmailId` varchar(200) NOT NULL,
  `Password` varchar(180) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Dob` varchar(100) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `City` varchar(200) NOT NULL,
  `Country` varchar(150) NOT NULL,
  `Phonenumber` char(11) NOT NULL,
  `Status` int(1) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`id`, `EmpId`, `FirstName`, `LastName`, `EmailId`, `Password`, `Gender`, `Dob`, `Department`, `Address`, `City`, `Country`, `Phonenumber`, `Status`, `RegDate`) VALUES
(1, 'BH1', 'Bharat ', 'Chaudhary', 'bharatchaudhary@gmail.com', '202cb962ac59075b964b07152d234b70', 'Male', '2000-06-23', 'Marketing', 'Radhanpur', 'Raadhanpur', 'India', '8469013600', 1, '2023-02-25 16:45:10'),
(10, 'PP2', 'Prince', 'Panchal', 'prince@Gmail.com', '202cb962ac59075b964b07152d234b70', 'Male', '1996-06-19', 'Information Technology', 'Hare Krishna society ', 'Radhanpur', 'India ', '8401052725', 1, '2023-02-25 17:33:18'),
(11, 'GP3', 'Gaurang', 'Panchal ', 'Gaurang@Gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Male', '1996-03-30', 'Human Resources ', 'Balaji ', 'Radhanpur', 'India ', '9624014590', 1, '2023-02-25 17:37:58'),
(12, 'NP', 'Nisarg', 'Patel', 'nisarg@Gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Male', '1995-01-19', 'Operations', 'greenpark', 'Radhanpur', 'India ', '8469190101', 1, '2023-02-25 17:45:25'),
(13, 'PS23', 'Piyush', 'Shrimali', 'piyush@Gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Male', '1997-08-08', 'Volunteer', 'Lalbag', 'Radhanpur', 'India ', '7487948817', 1, '2023-02-25 17:49:46'),
(14, 'KD', 'Krutik', 'darji', 'krutik@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Male', '1997-05-18', 'Finance', 'darjivas ', 'radhanpur', 'india', '9876552510', 1, '2023-02-25 17:52:43'),
(15, 'rd123', 'rahul ', 'darji', 'rahul@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Male', '2000-02-15', 'Sales', 'baspa', 'kamlpur', 'india', '9856324510', 1, '2023-02-25 17:54:59'),
(16, 'ap1112', 'akshay', 'panchal', 'akshay@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Male', '1997-12-11', 'Research', 'harekrishna', 'radhanpur', 'india', '9879011102', 1, '2023-02-25 17:58:22'),
(17, 'mt1111', 'meet', 'halani', 'meet@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Male', '2003-05-10', 'Human Resources ', 'lalbag', 'radhanpur', 'india', '7201984000', 1, '2023-02-25 18:00:37'),
(18, 'aa1199', 'apu', 'panchal', 'apu@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Male', '1999-11-12', 'Information Technology', 'shital ', 'radhanpur', 'india', '1452568942', 1, '2023-02-25 18:02:36');

-- --------------------------------------------------------

--
-- Table structure for table `tblleaves`
--

CREATE TABLE `tblleaves` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(110) NOT NULL,
  `ToDate` varchar(120) NOT NULL,
  `FromDate` varchar(120) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `AdminRemarkDate` varchar(120) DEFAULT NULL,
  `Status` int(1) NOT NULL,
  `IsRead` int(1) NOT NULL,
  `empid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblleaves`
--

INSERT INTO `tblleaves` (`id`, `LeaveType`, `ToDate`, `FromDate`, `Description`, `PostingDate`, `AdminRemark`, `AdminRemarkDate`, `Status`, `IsRead`, `empid`) VALUES
(23, 'Medical Leave', '2023-02-25', '2023-02-27', 'I has fever', '2023-02-25 18:23:10', NULL, NULL, 0, 0, 17),
(24, 'Paternity Leave', '2023-02-25', '2023-02-28', 'This is a demo description for testing purpose', '2023-02-25 18:29:37', NULL, NULL, 0, 0, 10),
(25, 'Adverse Weather Leave', '2023-02-28', '2023-03-03', 'This is a demo description for testing purpose', '2023-02-25 18:31:49', NULL, NULL, 0, 0, 1),
(26, 'Self-Quarantine Leave', '2023-03-02', '2023-03-05', 'This is a demo description for testing purpose', '2023-02-25 18:32:59', 'i can not satiesfy with your reason', '2023-02-26 0:31:51 ', 2, 1, 11),
(27, 'Adverse Weather Leave', '2023-03-04', '2023-03-05', 'This is a demo description for testing purpose', '2023-02-25 18:34:54', 'i can not satiesfy with your reason', '2023-02-26 0:31:32 ', 2, 1, 12),
(28, 'Maternity Leave', '2023-02-25', '2023-02-26', 'This is just a demo condition for testing purpose!!', '2023-02-25 18:36:57', 'i agree with your reason', '2023-02-26 0:30:43 ', 1, 1, 13),
(29, 'Bereavement Leave', '2023-02-25', '2023-03-30', 'This is just a demo condition for testing purpose!!', '2023-02-25 18:38:04', 'i agree with your reason', '2023-02-26 0:30:22 ', 1, 1, 14),
(30, 'Personal Time Off', '2023-02-28', '2023-03-05', 'This is just a demo condition for testing purpose!!', '2023-02-25 18:40:08', 'i can not satiesfy with ypur reason', '2023-02-26 0:29:54 ', 2, 1, 15),
(31, 'Medical Leave', '2023-02-26', '2023-02-27', 'I have to go for my body checkup. got an appointment for tomorrow ', '2023-02-25 18:45:18', 'i agree with your reason', '2023-02-26 0:28:59 ', 1, 1, 16);

-- --------------------------------------------------------

--
-- Table structure for table `tblleavetype`
--

CREATE TABLE `tblleavetype` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(200) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblleavetype`
--

INSERT INTO `tblleavetype` (`id`, `LeaveType`, `Description`, `CreationDate`) VALUES
(14, 'Casual Leave', 'Provided for urgent or unforeseen matter to the employee.', '2023-02-25 17:05:50'),
(15, 'Medical Leave', 'Related to Health Problems of Employee', '2023-02-25 17:19:36'),
(16, 'Restricted Holiday', 'Holiday that is optional', '2023-02-25 17:21:03'),
(17, 'Paternity Leave', 'To take care of newborns', '2023-02-25 17:21:58'),
(18, 'Bereavement Leave', 'Grieve their loss of losing loved ones', '2023-02-25 17:22:25'),
(19, 'Compensatory Leave', 'For Overtime workers', '2023-02-25 17:22:49'),
(20, 'Maternity Leave', 'Taking care of newborn ,recoveries', '2023-02-25 17:23:11'),
(21, 'Religious Holidays', 'Based on employee\\', '2023-02-25 17:23:53'),
(22, 'Adverse Weather Leave', 'In terms of extreme weather conditions', '2023-02-25 17:24:28'),
(23, 'Voting Leave', 'For official election day', '2023-02-25 17:24:58'),
(24, 'Self-Quarantine Leave', 'Related to COVID-19 issues', '2023-02-25 17:25:24'),
(25, 'Personal Time Off', 'To manage some private matters', '2023-02-25 17:25:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblleaves`
--
ALTER TABLE `tblleaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UserEmail` (`empid`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tblleaves`
--
ALTER TABLE `tblleaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
